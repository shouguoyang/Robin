# IDA script to extract functions & basic blocks from a binary
# this script saves the output in a Python pickle file
import idautils
import idaapi
import idc
import pickle
from collections import Counter
import time
import cPickle as pkl
import os.path
from collections import Counter
from idascript import *
if IDA_SDK_VERSION >= 700:
# IDAPro 6.x To 7.x (https://www.hex-rays.com/products/ida/support/ida74_idapython_no_bc695_porting_guide.shtml)
    GetOpType = get_operand_type
    GetOperandValue = get_operand_type
    SegName = get_segm_name
    autoWait = auto_wait
    GetFunctionName = get_func_name
    import ida_pro
    Exit = ida_pro.qexit

def generate_pickle_file(storageName, not_discard_subs):
	

	for seg in Segments():	
		if SegName(seg) == ".text":
			functions = Functions(seg)
			results = ''
			results_dict = {}
			count = 0
			func_list = list(functions)
			functions = Functions(seg)
			cnt = 0
			#tot_cnt = len(list(functions))

			for func_ea in functions:
				fname = GetFunctionName(func_ea)

				# if specify the target function name in IDA command, just extract only one target function and save
				if len(idc.ARGV) > 1:
					if fname != idc.ARGV[1]:
						continue

				cnt += 1
				if True: #analyse all the functions
					fd = FunctionDetails()
					print("Analyzing function '%s' %s" % (fname, str(cnt)))
					if fd.get_function_details(func_ea, not_discard_subs):
						basic_blocks_structure, bb_relations, basic_blocks_semantics, localVars_funcArgs, incall_outcall = fd.get_function_details(func_ea, not_discard_subs)

						#cendroid computation
						bb_list = []
						for key in bb_relations:
							for bb in bb_relations[key]:
								bb_list.append(key)
								bb_list.append(bb)

						total_w, cx, cy, cz = 0, 0, 0, 0
						inst_type, api_tags = [], []

						for bb_idx in basic_blocks_structure:
							ins_count = basic_blocks_structure[bb_idx][2]
							edge_count = bb_list.count(bb_idx)
							total_w += ins_count * edge_count
							cx += basic_blocks_structure[bb_idx][0] * ins_count * edge_count
							cy += basic_blocks_structure[bb_idx][1] * ins_count * edge_count
							cz += basic_blocks_structure[bb_idx][3] * ins_count * edge_count
							inst_type.extend(basic_blocks_semantics[bb_idx][0])
							api_tags.extend(basic_blocks_semantics[bb_idx][1])

						if total_w > 0:
							incall_func_list = list(set(incall_outcall[0]) & set(func_list))
							outcall_func_list = list(set(incall_outcall[1]) & set(func_list))

							results += ("%s,%f,%f,%f,%u\n" %(fname, float(cx)/float(total_w), float(cy)/float(total_w), float(cz)/float(total_w), total_w))
							results_dict[fname+"-"+str(func_ea)] = [float(cx)/float(total_w), float(cy)/float(total_w), float(cz)/float(total_w), total_w, Counter(inst_type), Counter(api_tags), len(localVars_funcArgs[0]), len(localVars_funcArgs[1]), incall_func_list, outcall_func_list]

				count += 1

			if len(idc.ARGV) > 1:
				storageName = storageName+"+"+idc.ARGV[1] # filename+function_name
				# storageName = idc.ARGV[2]+"+"+idc.ARGV[1] # filename+function_name

			fname = get_dump_name(storageName)
			pkl.dump(results_dict, open(fname, "wb"))

#set a good directory, is set NULL, the file will be stored at the location where this script is located.
# DIR = '/home/angr/bingo/pickle_files'
# DIR = '/home/angr/bingo/pickle_files_openssl'
# DIR = '/home/angr/bingo/pickle_files_ffmpeg'
# DIR = '/home/angr/bingo/pickle_files_freetype'
# DIR = '/home/angr/bingo/pickle_files_openssh'
DIR = '/home/angr/bingo/pickle_files_openssl'


def get_dump_name(filename):
	return os.path.join(DIR, filename + ".pickle")

if __name__ == '__main__':
	autoWait()
	t0 = time.time()
	print "\nFuntion extraction process starts"
	storageName = get_root_filename()
	not_discard_subs = True

	#old code 1
	# if os.path.isfile(get_dump_name(storageName)):
	# 	print("Pickle file %s already existed" %(get_dump_name(storageName)))
	# else:
	# 	generate_pickle_file(storageName, not_discard_subs)

	#new code 1
	generate_pickle_file(storageName, not_discard_subs)

	print("Done in %f seconds" %(time.time() - t0))
	Exit(1)
