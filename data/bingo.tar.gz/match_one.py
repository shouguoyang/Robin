from function_matching_model_for_openssl import get_dump_file, compute_similarity
import time

def match(vul_sig, bin_sig):
    to_print = vul_sig + " vs " + bin_sig
    vul_sig = vul_sig.replace(".pickle", "")
    bin_sig = bin_sig.replace(".pickle", "")
    vul_func_name = vul_sig.split("+")[1].split(".")[0]
    report_file = vul_sig +"_vs_"+bin_sig
    report_file1 = report_file+".match"
    report_file2 = report_file+".test"
    vul_sig = get_dump_file(vul_sig)
    bin_sig = get_dump_file(bin_sig)
    t0 = time.time() 
    local_sim = True
    ranks_to_print = 20
    str_return = compute_similarity(vul_sig, bin_sig, report_file1,ranks_to_print,local_sim, report_file2, vul_func=vul_func_name)
    
    to_write = ''
    to_write += 'sig_function,tar_function,accuracy_1,accuracy_3,accuracy_10,No of comparison, No of func in sig, No of funct in tar, time\n'


    to_write += to_print
    to_write += ","
    to_write += str_return[0]
    to_write += ","
    
    
    to_write += str_return[1]
    to_write += ","
    to_write += str_return[2]
    to_write += ","
    
    
    to_write += str(str_return[3])
    to_write += ","
    to_write += str(str_return[4])
    to_write += ","
    to_write += str(str_return[5])
    to_write += ","
    to_write += str(time.time() - t0)					

    to_write += "\n"	
    with open("reports/openssl","wb") as f:
        f.write(to_write)
        f.close()

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("vul_sig", help="path to vulnerability function signature file")
    ap.add_argument("bin_sig", help="path to binary signature file")
    args = ap.parse_args()

    vul_sig = args.vul_sig
    bin_sig = args.bin_sig
    match(vul_sig, bin_sig)
    
