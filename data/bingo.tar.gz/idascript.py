# 2021.08.28 16:05:42 CST
#Embedded file name: .\idascript.py
from idautils import *
from idaapi import *
from idc import *
import pickle
from collections import Counter
import time
import cPickle as pkl
import os.path
from utils.tarjan_sort import strongly_connected_components, robust_topological_sort
from utils.factor import FACTORS_CACHE, difference, difference_ratio, primesbelow as primes
from hashlib import md5
from cStringIO import StringIO
import json
GetFunctionName = get_func_name
if IDA_SDK_VERSION >= 700:
    GetManyBytes = get_bytes
    isCode = is_code
    GetFlags = get_full_flags
    FindFuncEnd = find_func_end
    GetMemberSize = get_member_size
    GetMemberName = get_member_name
    get_switch_info_ex = get_switch_info
    GetType = get_type
    GetFirstMember = get_first_member
    GetLastMember = get_last_member
    GetOpnd = print_operand
    GetFunctionCmt = get_func_cmt
    GetFunctionFlags = get_func_attr
# IDAPro 6.x To 7.x (https://www.hex-rays.com/products/ida/support/ida74_idapython_no_bc695_porting_guide.shtml)
    GetOpType = get_operand_type
    GetOperandValue = get_operand_type
    SegName = get_segm_name
    autoWait = auto_wait
    GetFunctionName = get_func_name
    import ida_pro
    from ida_ua import *
    Exit = ida_pro.qexit
    Demangle = demangle_name
    GetMnem = print_insn_mnem
    ItemSize = get_item_size
from collections import Counter
CMP_REPS = ['loc_',
 'sub_',
 'qword_',
 'dword_',
 'byte_',
 'word_',
 'off_',
 'unk_',
 'stru_',
 'dbl_',
 'locret_']
CMP_REMS = ['dword ptr ',
 'byte ptr ',
 'word ptr ',
 'qword ptr ']
API_TAGS = ['mem',
 'str',
 'cpy',
 'cat',
 'move',
 'host',
 'reg',
 'set',
 'get',
 'open',
 'write',
 'read',
 'close',
 'error',
 'len',
 'alloc',
 'brk',
 'fork',
 'io',
 'heap',
 'name',
 'crypt',
 'net',
 'socket',
 'sys',
 'file',
 'load',
 'lib',
 'cache',
 'mutex',
 'proc',
 'thread',
 'process',
 'sleep',
 'chk',
 'free',
 'put',
 'print',
 'stat',
 'chr',
 'char',
 'tod',
 'tol',
 'case',
 'scan',
 'env',
 'type',
 'seek',
 'wcs',
 'mb',
 'coll',
 'toul',
 'lock',
 'flush',
 'buf']
ins_to_type_mapping = {'mov': 'data_transfer',
 'movsx': 'data_transfer',
 'movss': 'data_transfer',
 'movzx': 'data_transfer',
 'cmov': 'data_transfer',
 'cmova': 'data_transfer',
 'cmovae': 'data_transfer',
 'cmovb': 'data_transfer',
 'cmovbe': 'data_transfer',
 'cmovc': 'data_transfer',
 'cmove': 'data_transfer',
 'cmovg': 'data_transfer',
 'cmovge': 'data_transfer',
 'cmovl': 'data_transfer',
 'cmovle': 'data_transfer',
 'cmovna': 'data_transfer',
 'cmovnae': 'data_transfer',
 'cmovnb': 'data_transfer',
 'cmovnbe': 'data_transfer',
 'cmovnc': 'data_transfer',
 'cmovne': 'data_transfer',
 'cmovng': 'data_transfer',
 'cmovnge': 'data_transfer',
 'cmovnl': 'data_transfer',
 'cmovnle': 'data_transfer',
 'cmovno': 'data_transfer',
 'cmovnp': 'data_transfer',
 'cmovns': 'data_transfer',
 'cmovnz': 'data_transfer',
 'cmovo': 'data_transfer',
 'cmovp': 'data_transfer',
 'cmovpe': 'data_transfer',
 'cmovpo': 'data_transfer',
 'cmovs': 'data_transfer',
 'cmovz': 'data_transfer',
 'set': 'data_transfer',
 'seta': 'data_transfer',
 'setae': 'data_transfer',
 'setb': 'data_transfer',
 'setbe': 'data_transfer',
 'setc': 'data_transfer',
 'sete': 'data_transfer',
 'setg': 'data_transfer',
 'setge': 'data_transfer',
 'setl': 'data_transfer',
 'setle': 'data_transfer',
 'setna': 'data_transfer',
 'setnae': 'data_transfer',
 'setnb': 'data_transfer',
 'setnbe': 'data_transfer',
 'setnc': 'data_transfer',
 'setne': 'data_transfer',
 'setng': 'data_transfer',
 'setnge': 'data_transfer',
 'setnl': 'data_transfer',
 'setnle': 'data_transfer',
 'setno': 'data_transfer',
 'setnp': 'data_transfer',
 'setns': 'data_transfer',
 'setnz': 'data_transfer',
 'seto': 'data_transfer',
 'setp': 'data_transfer',
 'setpe': 'data_transfer',
 'setpo': 'data_transfer',
 'sets': 'data_transfer',
 'setz': 'data_transfer',
 'xchg': 'data_transfer',
 'cmpxchg': 'data_transfer',
 'lea': 'data_transfer',
 'add': 'arithmetic',
 'adc': 'arithmetic',
 'sub': 'arithmetic',
 'sbb': 'arithmetic',
 'mul': 'arithmetic',
 'imul': 'arithmetic',
 'div': 'arithmetic',
 'neg': 'arithmetic',
 'idiv': 'arithmetic',
 'inc': 'arithmetic',
 'dec': 'arithmetic',
 'push': 'stack',
 'pop': 'stack',
 'pusha': 'stack',
 'pushf': 'stack',
 'popa': 'stack',
 'popf': 'stack',
 'and': 'logical',
 'or': 'logical',
 'not': 'logical',
 'cmp': 'comparison',
 'test': 'comparison',
 'xor': 'logical',
 'shr': 'shift_rotate',
 'shl': 'shift_rotate',
 'sal': 'shift_rotate',
 'sar': 'shift_rotate',
 'rol': 'shift_rotate',
 'ror': 'shift_rotate',
 'rcl': 'shift_rotate',
 'rcr': 'shift_rotate',
 'jno': 'control_transfer',
 'jnp': 'control_transfer',
 'jns': 'control_transfer',
 'jmp': 'control_transfer',
 'jo': 'control_transfer',
 'jp': 'control_transfer',
 'jpe': 'control_transfer',
 'jpo': 'control_transfer',
 'js': 'control_transfer',
 'jecxz': 'control_transfer',
 'jcxz': 'control_transfer',
 'jz': 'control_transfer',
 'jnz': 'control_transfer',
 'jmp': 'control_transfer',
 'je': 'control_transfer',
 'jne': 'control_transfer',
 'ljmp': 'control_transfer',
 'jge': 'control_transfer',
 'ja': 'control_transfer',
 'jae': 'control_transfer',
 'jb': 'control_transfer',
 'jbe': 'control_transfer',
 'jl': 'control_transfer',
 'jle': 'control_transfer',
 'jno': 'control_transfer',
 'jnp': 'control_transfer',
 'jrcxz': 'control_transfer',
 'loop': 'loop',
 'loopne': 'loop',
 'loopnz': 'loop',
 'loope': 'loop',
 'loopz': 'loop',
 'cmps': 'string',
 'cmpsb': 'string',
 'cmpsw': 'string',
 'cmpsd': 'string',
 'cmpsq': 'string',
 'lods': 'string',
 'lodsb': 'string',
 'lodsw': 'string',
 'lodsd': 'string',
 'lodsq': 'string',
 'movs': 'string',
 'movsb': 'string',
 'movsw': 'string',
 'movsd': 'string',
 'movsq': 'string',
 'scas': 'string',
 'scasb': 'string',
 'scasw': 'string',
 'scasd': 'string',
 'scasq': 'string',
 'stos': 'string',
 'stosb': 'string',
 'stosw': 'string',
 'stosd': 'string',
 'stosq': 'string',
 'rep': 'string',
 'cld': 'flag',
 'clc': 'flag',
 'stc': 'flag',
 'std': 'flag',
 'cmc': 'flag',
 'sti': 'flag',
 'cli': 'flag',
 'xlatb': 'flag',
 'lahf': 'flag',
 'hlt': 'misc',
 'wait': 'misc',
 'set': 'misc',
 'leave': 'misc',
 'cbw': 'sign',
 'cwd': 'sign',
 'cwde': 'sign',
 'cdq': 'sign',
 'csq': 'sign',
 'fld': 'stack_fpu',
 'fst': 'stack_fpu',
 'fstp': 'stack_fpu',
 'fxch': 'stack_fpu',
 'mulps': 'arithmetic_fpu',
 'addps': 'arithmetic_fpu',
 'sqrtss': 'arithmetic_fpu',
 'maxps': 'arithmetic_fpu',
 'vsubpd': 'arithmetic_fpu',
 'vpsubsb': 'arithmetic_fpu',
 'vmulss': 'arithmetic_fpu',
 'vminsd': 'arithmetic_fpu',
 'subss': 'arithmetic_fpu',
 'subps': 'arithmetic_fpu',
 'subsd': 'arithmetic_fpu',
 'divss': 'arithmetic_fpu',
 'addss': 'arithmetic_fpu',
 'addsd': 'arithmetic_fpu',
 'mulsd': 'arithmetic_fpu',
 'mulss': 'arithmetic_fpu',
 'fmul': 'arithmetic_fpu',
 'fdiv': 'arithmetic_fpu',
 'fcomp': 'arithmetic_fpu',
 'fadd': 'arithmetic_fpu',
 'movups': 'data_transfer_fpu',
 'movaps': 'data_transfer_fpu',
 'andps': 'logical_fpu',
 'orps': 'logical_fpu',
 'xorps': 'logical_fpu',
 'cmpps': 'logical_fpu',
 'ucomiss': 'logical_fpu',
 'rcpss': 'misc_fpu',
 'cvtpi2ps': 'convert_fpu',
 'cvtps2pd': 'convert_fpu',
 'cvtsd2ss': 'convert_fpu',
 'cvtsi2sd': 'convert_fpu',
 'cvtsi2ss': 'convert_fpu',
 'cvtss2sd': 'convert_fpu',
 'call': 'call',
 'lcall': 'call',
 'sysenter': 'call',
 'enter': 'call',
 'int': 'call',
 'in': 'port',
 'out': 'port'}

class FunctionDetails():

    def __init__(self):
        self.names = dict(Names())
        self.primes = primes(1048576)
        self.ida_subs = True

    def get_base_address(self):
        return get_imagebase()

    def get_cmp_asm_lines(self, asm):
        sio = StringIO(asm)
        lines = []
        get_cmp_asm = self.get_cmp_asm
        for line in sio.readlines():
            line = line.strip('\n')
            lines.append(get_cmp_asm(line))

        return '\n'.join(lines)

    def get_cmp_asm(self, asm):
        if asm is None:
            return asm
        tmp = asm.split(';')[0]
        tmp = tmp.split(' # ')[0]
        for rep in CMP_REPS:
            tmp = re.sub(rep + '[a-f0-9A-F]+', 'XXXX', tmp)

        for rep in CMP_REMS:
            tmp = re.sub(rep + '[a-f0-9A-F]+', '', tmp)

        reps = ['\\+[a-f0-9A-F]+h\\+']
        for rep in reps:
            tmp = re.sub(rep, '+XXXX+', tmp)

        tmp = re.sub('\\.\\.[a-f0-9A-F]{8}', 'XXX', tmp)
        tmp = re.sub('[ \t\n]+$', '', tmp)
        return tmp

    def find_all_callees(self, start_ea):
        """Return a set of all callees called from the specified function."""
        callees = {}
        visited = set([])
        pending = set([start_ea])
        while len(pending) > 0:
            start_ea = pending.pop()
            fname = GetFunctionName(start_ea)
            if not fname:
                continue
            callees[start_ea] = fname
            visited.add(start_ea)
            end_ea = FindFuncEnd(start_ea)
            if end_ea == BADADDR:
                continue
            all_refs = set([])
            for head in Heads(start_ea, end_ea):
                if not isCode(GetFlags(head)):
                    continue
                refs = CodeRefsFrom(head, 0)
                refs = set(filter(lambda x: not (x >= start_ea and x <= end_ea), refs))
                all_refs |= refs

            all_refs -= visited
            pending |= all_refs

        return callees.keys()

    def get_neighboring_func(self, func_ea):
        in_call_list = list(CodeRefsTo(func_ea, 0))
        tmp_in_call_list = []
        for f in in_call_list:
            if not isinstance(f, type(None)):
                try:
                    tmp_in_call_list.append(get_func(f).start_ea)
                except:
                    continue

        in_call_list = list(set(tmp_in_call_list) - set([func_ea]))
        out_call_list = self.find_all_callees(func_ea)
        out_call_list = list(set(out_call_list) - set([func_ea]))
        return (in_call_list, out_call_list)


    def getLocalVarFuncArgList(self, ea):
        local_variables = []
        arguments = []
        current = local_variables
        # frame = GetFrame(ea)
        ea = ea.start_ea
        print ea,type(ea)
        frame = get_func_attr(ea, FUNCATTR_FRAME)
        if frame == None:
            return [[], []]
        start = GetFirstMember(frame)
        end = GetLastMember(frame)
        count = 0
        while start <= end and count <= 10000:
            size = GetMemberSize(frame, start)
            count = count + 1
            if size == None:
                start = start + 1
                continue
            name = GetMemberName(frame, start)
            start += size
            if name in (' r', ' s'):
                current = arguments
                continue
            current.append(name)

        return (local_variables, arguments)

    def get_function_details(self, f, not_discard_subs = True):
        func_ea = f
        name = GetFunctionName(int(f))
        true_name = name
        demangled_name = Demangle(name, INF_SHORT_DN)
        if demangled_name is not None:
            name = demangled_name
        f = int(f)
        func = get_func(f)
        flow = FlowChart(func)
        size = 0
        self.ida_subs = not_discard_subs
        if not self.ida_subs:
            if name.startswith('sub_') or name.startswith('j_') or name.startswith('unknown'):
                return False
            flags = GetFunctionFlags(f, FUNCATTR_FLAGS)
            if flags & FUNC_LIB or flags == -1:
                return False
        nodes = 0
        edges = 0
        instructions = 0
        mnems = []
        dones = {}
        names = set()
        bytes_hash = []
        bytes_sum = 0
        function_hash = []
        outdegree = 0
        indegree = len(list(CodeRefsTo(f, 1)))
        assembly = {}
        basic_blocks_data = {}
        basic_blocks_data_3dcfg_structure = {}
        basic_blocks_data_3dcfg_semantics = {}
        bbaddr_to_idx = {}
        bb_relations = {}
        bb_topo_num = {}
        bb_topological = {}
        switches = []
        mnemonics_spp = 1
        cpu_ins_list = GetInstructionList()
        cpu_ins_list.sort()
        image_base = 0
        for block in flow:
            nodes += 1
            instructions_data = []
            block_ea = block.start_ea - image_base
            idx = len(bb_topological)
            bb_topological[idx] = []
            bb_topo_num[block_ea] = idx
            bbaddr_to_idx[block_ea] = idx
            outdegree_bb = 0
            mnem_bb = []
            api_bb = []
            for x in list(Heads(block.start_ea, block.end_ea)):
                mnem = GetMnem(x)
                disasm = GetDisasm(x)
                size += ItemSize(x)
                instructions += 1
                if mnem in cpu_ins_list:
                    mnemonics_spp += self.primes[cpu_ins_list.index(mnem)]
                try:
                    assembly[block_ea].append(disasm)
                except KeyError:
                    if nodes == 1:
                        assembly[block_ea] = [disasm]
                    else:
                        assembly[block_ea] = ['loc_%x:' % x, disasm]
                decoded_size = decode_insn(insn_t(), x)
                if insn_t().Op1.type in [o_mem,
                 o_imm,
                 o_far,
                 o_near,
                 o_displ]:
                    decoded_size -= insn_t().Op1.offb
                if insn_t().Op2.type in [o_mem,
                 o_imm,
                 o_far,
                 o_near,
                 o_displ]:
                    decoded_size -= insn_t().Op2.offb
                if decoded_size <= 0:
                    decoded_size = 1
                curr_bytes = GetManyBytes(x, decoded_size)
                bytes_hash.append(curr_bytes)
                bytes_sum += sum(map(ord, curr_bytes))
                function_hash.append(GetManyBytes(x, ItemSize(x)))
                outdegree += len(list(CodeRefsFrom(x, 0)))
                outdegree_bb += len(list(CodeRefsFrom(x, 0)))
                mnems.append(mnem)
                mnem_bb.append(mnem)
                op_value = GetOperandValue(x, 1)
                if op_value == BADADDR:
                    op_value = GetOperandValue(x, 0)
                if mnem == 'call':
                    api = GetOpnd(x, 0)
                    matched_tags = [ tag for tag in API_TAGS if tag in api ]
                    api_bb.extend(matched_tags)
                if op_value != BADADDR and op_value in self.names:
                    tmp_name = self.names[op_value]
                    demangled_name = Demangle(name, INF_SHORT_DN)
                    if demangled_name is not None:
                        tmp_name = demangled_name
                    if not tmp_name.startswith('sub_'):
                        names.add(tmp_name)
                l = list(CodeRefsFrom(x, 0))
                if len(l) == 0:
                    l = DataRefsFrom(x)
                tmp_name = None
                tmp_type = None
                for ref in l:
                    if ref in self.names:
                        tmp_name = self.names[ref]
                        tmp_type = GetType(ref)

                ins_cmt1 = GetCommentEx(x, 0)
                ins_cmt2 = GetCommentEx(x, 1)
                instructions_data.append([x - image_base,
                 mnem,
                 disasm,
                 ins_cmt1,
                 ins_cmt2])
                switch = get_switch_info_ex(x)
                if switch:
                    switch_cases = switch.get_jtable_size()
                    switch_low_case = switch.lowcase
                    results = calc_switch_cases(x, switch)
                    can_iter = False
                    switch_cases_values = set()
                    for idx in xrange(len(results.cases)):
                        cur_case = results.cases[idx]
                        if '__iter__' not in dir(cur_case):
                            break
                        can_iter |= True
                        for cidx in xrange(len(cur_case)):
                            case_id = cur_case[cidx]
                            switch_cases_values.add(case_id)

                    if can_iter:
                        switches.append([switch_cases, list(switch_cases_values)])

            mnem_to_type = [ ins_to_type_mapping[mnem] for mnem in mnem_bb if mnem in ins_to_type_mapping ]
            basic_blocks_data_3dcfg_structure[block_ea] = [idx, outdegree_bb, len(mnem_bb)]
            basic_blocks_data_3dcfg_semantics[block_ea] = [mnem_to_type, api_bb]
            basic_blocks_data[block_ea] = instructions_data
            bb_relations[block_ea] = []
            for succ_block in block.succs():
                succ_base = succ_block.start_ea - image_base
                bb_relations[block_ea].append(succ_base)
                edges += 1
                indegree += 1
                if not dones.has_key(succ_block.id):
                    dones[succ_block] = 1

            for pred_block in block.preds():
                try:
                    bb_relations[pred_block.start_ea - image_base].append(block.start_ea - image_base)
                except KeyError:
                    bb_relations[pred_block.start_ea - image_base] = [block.start_ea - image_base]

                edges += 1
                outdegree += 1
                if not dones.has_key(succ_block.id):
                    dones[succ_block] = 1

        for block in flow:
            block_ea = block.start_ea - image_base
            for succ_block in block.succs():
                succ_base = succ_block.start_ea - image_base
                bb_topological[bb_topo_num[block_ea]].append(bb_topo_num[succ_base])

        strongly_connected_spp = 0
        try:
            strongly_connected = strongly_connected_components(bb_relations)
            bb_topological = robust_topological_sort(bb_topological)
            bb_topological = json.dumps(bb_topological)
            strongly_connected_spp = 1
            for item in strongly_connected:
                val = len(item)
                if val > 1:
                    strongly_connected_spp *= self.primes[val]

        except:
            strongly_connected = []
            bb_topological = None

        loops = 0
        loops_list = []
        for sc in strongly_connected:
            if len(sc) > 1:
                loops_list.append(list(sc))
                loops += 1
            elif sc[0] in bb_relations and sc[0] in bb_relations[sc[0]]:
                loops_list.append(list(sc))
                loops += 1

        asm = []
        keys = assembly.keys()
        keys.sort()
        keys.remove(f - image_base)
        keys.insert(0, f - image_base)
        for key in keys:
            asm.extend(assembly[key])

        asm = '\n'.join(asm)
        cc = edges - nodes + 2
        prime = str(self.primes[cc])
        comment = GetFunctionCmt(f, 1)
        bytes_hash = md5(''.join(bytes_hash)).hexdigest()
        function_hash = md5(''.join(function_hash)).hexdigest()
        function_flags = GetFunctionFlags(f, FUNCATTR_FLAGS)
        clean_assembly = ''
        proto2 = GetType(f)
        rva = f - self.get_base_address()
        for key in basic_blocks_data_3dcfg_structure:
            loop_idx = next((sublist.index(key) + 1 for i, sublist in enumerate(loops_list) if key in sublist), 0)
            basic_blocks_data_3dcfg_structure[key].append(loop_idx)

        var_tuple = self.getLocalVarFuncArgList(func)
        neighbor_tuple = self.get_neighboring_func(func_ea)
        return (basic_blocks_data_3dcfg_structure,
         bb_relations,
         basic_blocks_data_3dcfg_semantics,
         var_tuple,
         neighbor_tuple)
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2021.08.28 16:05:42 CST
